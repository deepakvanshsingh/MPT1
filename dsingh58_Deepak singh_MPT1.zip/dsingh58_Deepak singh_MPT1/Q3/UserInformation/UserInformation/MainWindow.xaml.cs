﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace UserInformation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string conString = ConfigurationManager.ConnectionStrings["conString"].ConnectionString;
        SqlConnection connection = new SqlConnection(conString);
        SqlCommand cmd;
      
        public MainWindow()
        {
            InitializeComponent();
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string query = "select * from Users_dsingh58 where UserId=" + int.Parse(userId.Text) + "";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    userName.Text = reader[1].ToString();
                    userEmail.Text = reader[2].ToString();
                    userContact.Text = reader[3].ToString();
                    userAddress.Text = reader[4].ToString();
                }


            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = int.Parse(userId.Text);
                string query = "delete Users_dsingh58 where UserId=" + id + "";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int status = cmd.ExecuteNonQuery();
                if (status > 0)
                {
                    MessageBox.Show("Record Deleted Successfully!!");
                   

                }
                else
                {
                    MessageBox.Show("Issue in deleting the record");
                }
            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
              
                string name = userName.Text;
                string email = userEmail.Text;
                string contact =userContact.Text;
                string address = userAddress.Text;
                string query = "insert into  Users_dsingh58 values('" + name + "','" + email + "','" + contact + "','"+address+"')";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int status = cmd.ExecuteNonQuery();
                if (status > 0)
                {
                    MessageBox.Show("Record Added Successfully!!");
                  

                }
                else
                {
                    MessageBox.Show("Issue in adding the record");
                }
            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

           
            try
            {

                string query = "select * from Users_dsingh58";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                userDetails.DataContext = table;


            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = int.Parse(userId.Text);
                string name = userName.Text;
                string email = userEmail.Text;
                string contact = userContact.Text;
                string address = userAddress.Text;

                string query = "UPDATE Users_dsingh58 SET  Username='" + name + "',Email='"+email+"',Contactnumber='"+contact+"',Address='"+address+"'  where UserId=" + id + "";
                cmd = new SqlCommand(query, connection);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                int status = cmd.ExecuteNonQuery();
                if (status > 0)
                {
                    MessageBox.Show("Record Updated Successfully!!");
                

                }
                else
                {
                    MessageBox.Show("Issue in adding the record");
                }
            }
            catch (SqlException EX)
            {
                MessageBox.Show("Exception occured!!!" + EX.Message);
            }
            finally
            {
                cmd.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
    }
    }

