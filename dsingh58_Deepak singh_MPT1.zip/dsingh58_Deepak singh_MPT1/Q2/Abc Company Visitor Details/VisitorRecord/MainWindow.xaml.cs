﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VisitorRecord
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_23Jan20_PuneEntities context = new Training_23Jan20_PuneEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string name = userName.Text;
            string passsword1 = userPassword.Password.ToString();
            string passsword2 = userRPassword.Password.ToString();
          
            if (passsword1.Equals(passsword2)) {
                MessageBox.Show("Password matched!!");
          
            }
            else
            {
                MessageBox.Show("Password does not match!!");
                return;

            }
            string email = userEmail.Text;
            string country = userCountry.SelectionBoxItem.ToString();
            string contact = userContact.Text;
            string address = userAddress.Text;



            Tbl_Users_dsingh58 userTbl = new Tbl_Users_dsingh58()
            {
                Username = name,
                Password = passsword1,
                Email = email,
                Country = country,
                Contactnumber = contact,
                Address = address
        };

            context.Tbl_Users_dsingh58.Add(userTbl);
            MessageBox.Show("Added successfully!!");
            context.SaveChanges();
        }
    }
}
